# React + Redux Boilerplate

### INSTRUCTIONS 
 - Install YARN globally through <code> npm install -g yarn</code>
 - Install dependencies by runing command: <code> yarn install </code>
 - Start app by <code> yarn start </code>


 - To make production built, run command <code> yarn run build </code>
