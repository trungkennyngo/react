import React, { useState } from "react";

import Child from "./Child";

const App = () => {
  const [state, setState] = useState("");

  let name = a => {
    setState(state => a);
  };

  return (
    <div className="App">
      <h1>Parent Value: {state}</h1>
      <Child name={name} />
    </div>
  );
};

export default App;
